
public enum TemperatureUnit {
	celsius, fahrenheit, kelvin
}
